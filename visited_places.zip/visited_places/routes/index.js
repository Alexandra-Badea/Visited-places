var express = require('express');
const app = require('../app');
var router = express.Router();
const mongoose = require('mongoose');
const VisitedPlaceModel = require('../models/visitedplace-model');

/* GET home page. */
router.get('/', function(req, res, next) {
  VisitedPlaceModel.find({}, function (err, docs) {
    if (err) {
      res.send(err);
    }
    else{
      res.render('index', { title: 'Visited Countries', countries: JSON.stringify(docs) });
    }
  });
});

router.post('/add', function(req, res, next) {
  let newVisitedPlace = new VisitedPlaceModel({
      city: req.body.city,
      country: req.body.country,
      countryCode: req.body.country_code.toUpperCase(),
      visitedDate: req.body.visited_date,
      visitedDays: req.body.visited_days
  });

  newVisitedPlace.save(function(err, newVisitedPlace) {
      if(err)
          res.send(err);
      else
          res.redirect('/');
  });

});

router.get('/country', function(req, res, next) {
  numeleTarii = req.query.name;
  if (numeleTarii === undefined) {
    res.send("Lipseste numele tarii.");
  }
  VisitedPlaceModel.find({country: numeleTarii}, function (err, docs) {
    if (err) {
      res.send(err);
    }
    else{
      if(docs.length==0){
        res.send("Nu exista vizite in aceasta tara: "+numeleTarii);
      }
      res.render('country', {countryName: numeleTarii, places: JSON.stringify(docs)});
    }
  });
})

module.exports = router;