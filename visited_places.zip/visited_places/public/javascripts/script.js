let visitedCities = []

let countriesList = JSON.parse(document.getElementById('countriesList').innerHTML);

visitedCities = countriesList;

countriesList = ['Country'];

visitedCities.forEach(city => {
    if (!countriesList.includes(city.country)) {
        countriesList.push(city.country)
    } 
});

countriesList = countriesList.map(x => [x]);

google.charts.load('current', {
    'packages': ['geochart'],
    'mapsApiKey': 'AIzaSyAGIqX5HXg_5H3CLfrzhbSL-VuosvsNVkM'
});
google.charts.setOnLoadCallback(drawRegionsMap);

function drawRegionsMap() {

    var data = google.visualization.arrayToDataTable(countriesList);

    var options = {
        region: '150',
        // displayMode: 'markers',
        // colorAxis: {colors: ['green', 'blue']}
    };

    var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));
    chart.draw(data, options);

    google.visualization.events.addListener(chart, 'select', selectHandler);
function selectHandler(e) { 
    let selectedItem = chart.getSelection()[0].row;
    let value = countriesList[selectedItem+1];
    console.log(value);

    location.href="/country?name=" + value;
  }
};





