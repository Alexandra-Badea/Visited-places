let visitedList = JSON.parse(document.getElementById('places').innerHTML);
let countryCode = visitedList[0].countryCode;

google.charts.load('current', {
    'packages': ['geochart'],
    'mapsApiKey': 'AIzaSyAGIqX5HXg_5H3CLfrzhbSL-VuosvsNVkM'
});

google.load('visualization', '1', {'packages': ['geochart']});
google.setOnLoadCallback(drawMarkersMap);

citiesList = [['City', 'Days']];

visitedList.forEach(city => {
    if (!citiesList.includes(city.city)) {
        citiesList.push([city.city, Number(city.visitedDays)])
    } 
});

console.log(citiesList)

function drawMarkersMap() {

    var data = google.visualization.arrayToDataTable(citiesList);

    var options = {
        region: countryCode,
        // displayMode: 'region',
        displayMode: 'markers',
        resolution: 'provinces',
        legend: 'none',
        enableRegionInteractivity: 'true',
        legend: { textStyle: { color: 'black', fontSize: 14 } },
        // width: 1000,
        // height: 624,
        // sizeAxis: {minSize:1,  maxSize: 5},
        // defaultColor: '#FF0000' ,
        // colorAxis: {colors: ['#000000', '#222222']},
        colorAxis: { colors: ['green', 'blue'] },
        backgroundColor: 'white',
        datalessRegionColor: '#F2F2F2'
    };

    var chart = new google.visualization.GeoChart(document.getElementById('chart_div'));
    chart.draw(data, options);
};

