const mongoose = require('mongoose');

var visitedplaceSchema = mongoose.Schema({
    city: {
        type: String,
        required: true
    },
    country: {
        type: String,
        required: true
    },
    countryCode: {
        type: String,
        required: true
    },
    visitedDate: {
        type: String,
        required: true
    },
    visitedDays: {
        type: String,
        required: true
    }
});

var VisitedPlaceModel = mongoose.model('VisitedPlace', visitedplaceSchema);

module.exports = VisitedPlaceModel;